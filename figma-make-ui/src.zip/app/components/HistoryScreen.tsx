import { ArrowLeft, CheckCircle2, Clock, MapPin } from 'lucide-react';
import warsawIllustration from '../../imports/______________2026-05-06___20.11.04-1.png';

interface HistoryScreenProps {
  onNavigate: (screen: string) => void;
}

const reports = [
  {
    id: 1,
    title: 'Uszkodzona ławka',
    location: 'Park Łazienkowski',
    date: '6 maja 2026',
    status: 'sent',
    category: 'Infrastruktura parkowa'
  },
  {
    id: 2,
    title: 'Dziura w chodniku',
    location: 'ul. Marszałkowska 84',
    date: '3 maja 2026',
    status: 'completed',
    category: 'Drogi i chodniki'
  },
  {
    id: 3,
    title: 'Pełny kosz na śmieci',
    location: 'Plac Zbawiciela',
    date: '28 kwietnia 2026',
    status: 'completed',
    category: 'Czystość'
  }
];

export function HistoryScreen({ onNavigate }: HistoryScreenProps) {
  return (
    <div className="flex flex-col h-full relative overflow-hidden">
      {/* Warsaw Illustration Background */}
      <div className="absolute inset-0 -z-10">
        <img
          src={warsawIllustration}
          alt=""
          className="w-full h-full object-cover opacity-[0.18]"
          style={{ filter: 'blur(1px) saturate(0.8)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#faf9f7]/85 via-[#fdfcfa]/80 to-[#fef9f5]/85" />
      </div>
      {/* Header */}
      <div className="px-6 pt-12 pb-6 border-b border-border bg-card">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => onNavigate('home')}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
            Historia
          </h2>
        </div>
        <p className="text-sm text-muted-foreground">
          Twoje zgłoszenia i ich status
        </p>
      </div>

      {/* Reports List */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-3">
        {reports.map((report) => (
          <div
            key={report.id}
            className="bg-card border border-border rounded-2xl p-5 active:scale-[0.99] transition-transform"
          >
            <div className="flex items-start justify-between mb-3">
              <h3 className="text-lg flex-1" style={{ fontFamily: 'var(--font-serif)' }}>
                {report.title}
              </h3>
              {report.status === 'completed' ? (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-green-500/10 text-green-700 rounded-full text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Zrealizowane
                </div>
              ) : (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-primary/10 text-primary rounded-full text-xs">
                  <Clock className="w-3.5 h-3.5" />
                  Wysłane
                </div>
              )}
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                {report.location}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{report.date}</span>
                <span className="text-xs text-muted-foreground">{report.category}</span>
              </div>
            </div>
          </div>
        ))}

        {reports.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <div className="mb-2">Brak zgłoszeń</div>
            <button
              onClick={() => onNavigate('home')}
              className="text-primary text-sm"
            >
              Utwórz pierwsze zgłoszenie
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
