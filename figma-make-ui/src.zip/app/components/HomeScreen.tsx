import { Camera, MapPin, Users } from 'lucide-react';
import { useState } from 'react';
import warsawIllustration from '../../imports/______________2026-05-06___20.11.04-1.png';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

const nearbyReports = [
  {
    id: 1,
    title: 'Uszkodzona ławka w parku',
    distance: '120 m',
    category: 'Infrastruktura',
    supporters: 2,
    image: 'bench'
  },
  {
    id: 2,
    title: 'Dziura w chodniku',
    distance: '340 m',
    category: 'Drogi',
    supporters: 5,
    image: 'sidewalk'
  },
  {
    id: 3,
    title: 'Pełny kosz przy przystanku',
    distance: '580 m',
    category: 'Czystość',
    supporters: 1,
    image: 'trash'
  },
  {
    id: 4,
    title: 'Niesprawne oświetlenie uliczne',
    distance: '720 m',
    category: 'Oświetlenie',
    supporters: 0,
    image: 'light'
  }
];

const myReports = [
  {
    id: 1,
    title: 'Uszkodzona ławka w parku',
    distance: '120 m',
    category: 'Infrastruktura',
    supporters: 2,
    image: 'bench'
  }
];

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [activeTab, setActiveTab] = useState<'nearby' | 'mine'>('nearby');

  const reports = activeTab === 'nearby' ? nearbyReports : myReports;

  return (
    <div className="flex flex-col h-full relative overflow-hidden">
      {/* Warsaw Illustration Background */}
      <div className="absolute inset-0 -z-10">
        <img
          src={warsawIllustration}
          alt=""
          className="w-full h-full object-cover opacity-[0.18]"
          style={{ filter: 'blur(1px) saturate(0.8)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#faf9f7]/85 via-[#fdfcfa]/80 to-[#fef9f5]/85" />
      </div>

      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <h1 className="text-4xl mb-2 text-foreground" style={{ fontFamily: 'var(--font-serif)' }}>
          Warszawiak
        </h1>
        <p className="text-muted-foreground">
          Zobacz, co dzieje się w Twojej okolicy
        </p>
      </div>

      {/* Tabs */}
      <div className="px-6 mb-4">
        <div className="flex gap-2 bg-white/60 backdrop-blur-sm rounded-2xl p-1.5 border border-border/50">
          <button
            onClick={() => setActiveTab('mine')}
            className={`flex-1 py-2.5 rounded-xl transition-all ${
              activeTab === 'mine'
                ? 'bg-white text-foreground shadow-sm'
                : 'text-muted-foreground'
            }`}
          >
            Moje zgłoszenia
          </button>
          <button
            onClick={() => setActiveTab('nearby')}
            className={`flex-1 py-2.5 rounded-xl transition-all ${
              activeTab === 'nearby'
                ? 'bg-white text-foreground shadow-sm'
                : 'text-muted-foreground'
            }`}
          >
            W okolicy
          </button>
        </div>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto px-6 pb-24 space-y-3">
        {reports.map((report) => (
          <div
            key={report.id}
            className="bg-white/80 backdrop-blur-sm border border-border/50 rounded-2xl overflow-hidden active:scale-[0.99] transition-transform shadow-sm"
          >
            <div className="flex gap-4 p-4">
              {/* Image Preview */}
              <div className="w-20 h-20 bg-gradient-to-br from-gray-200 to-gray-300 rounded-xl flex-shrink-0 overflow-hidden">
                <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
                  {report.image}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h3 className="mb-1.5 leading-snug" style={{ fontFamily: 'var(--font-serif)' }}>
                  {report.title}
                </h3>

                <div className="flex items-center gap-2 mb-2">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5" />
                    {report.distance}
                  </div>
                  <div className="w-1 h-1 rounded-full bg-border" />
                  <span className="text-xs text-muted-foreground">{report.category}</span>
                </div>

                {/* Community Indicator */}
                {report.supporters > 0 ? (
                  <div className="flex items-center gap-1.5 text-xs text-primary">
                    <Users className="w-3.5 h-3.5" />
                    <span>{report.supporters} {report.supporters === 1 ? 'osoba zgłosiła' : 'osoby zgłosiły'}</span>
                  </div>
                ) : (
                  <button className="text-xs text-primary">
                    Dołącz do zgłoszenia
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {reports.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <p className="mb-2">Brak zgłoszeń</p>
            <p className="text-sm">Zgłoś pierwszy problem w okolicy</p>
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      <div className="absolute bottom-6 right-6">
        <button
          onClick={() => onNavigate('camera')}
          className="w-16 h-16 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center active:scale-95 transition-transform"
        >
          <Camera className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
}
