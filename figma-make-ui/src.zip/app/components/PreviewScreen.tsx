import { CheckCircle2, MapPin, Calendar, Send, X } from 'lucide-react';
import warsawIllustration from '../../imports/______________2026-05-06___20.11.04-1.png';

interface PreviewScreenProps {
  onNavigate: (screen: string) => void;
}

export function PreviewScreen({ onNavigate }: PreviewScreenProps) {
  const handleSend = () => {
    setTimeout(() => {
      onNavigate('history');
    }, 400);
  };

  return (
    <div className="flex flex-col h-full relative overflow-hidden">
      {/* Warsaw Illustration Background */}
      <div className="absolute inset-0 -z-10">
        <img
          src={warsawIllustration}
          alt=""
          className="w-full h-full object-cover opacity-[0.18]"
          style={{ filter: 'blur(1px) saturate(0.8)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#faf9f7]/85 via-[#fdfcfa]/80 to-[#fef9f5]/85" />
      </div>
      {/* Header */}
      <div className="px-6 pt-12 pb-6 border-b border-border bg-card">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => onNavigate('camera')}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="text-sm text-muted-foreground">Podgląd zgłoszenia</div>
          <div className="w-10" />
        </div>
        <h2 className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
          Uszkodzona ławka
        </h2>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4">
        {/* AI Detection Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-full">
          <CheckCircle2 className="w-4 h-4" />
          <span className="text-sm">Wykryto automatycznie</span>
        </div>

        {/* Photo Preview */}
        <div className="aspect-[4/3] bg-gradient-to-br from-gray-200 to-gray-300 rounded-2xl overflow-hidden">
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <div className="text-sm">Zdjęcie zgłoszenia</div>
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
          <div>
            <div className="text-sm text-muted-foreground mb-1">Kategoria</div>
            <div>Infrastruktura parkowa</div>
          </div>

          <div className="flex items-start gap-2">
            <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="text-sm text-muted-foreground mb-1">Lokalizacja</div>
              <div>Park Łazienkowski, al. Ujazdowskie</div>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <Calendar className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="text-sm text-muted-foreground mb-1">Data zgłoszenia</div>
              <div>6 maja 2026, 14:32</div>
            </div>
          </div>
        </div>

        {/* AI Generated Report */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <h3 className="mb-3" style={{ fontFamily: 'var(--font-serif)' }}>
            Opis zgłoszenia
          </h3>
          <p className="text-sm leading-relaxed text-foreground/90">
            Zgłaszam uszkodzoną ławkę parkową znajdującą się w Parku Łazienkowskim przy alei Ujazdowskiej.
            Ławka posiada połamane elementy drewniane oraz obluzowane mocowania, co stanowi zagrożenie
            dla bezpieczeństwa użytkowników. Proszę o naprawę lub wymianę ławki.
          </p>
          <div className="mt-3 text-xs text-muted-foreground">
            ✨ Wygenerowano przez AI
          </div>
        </div>

        {/* Department Info */}
        <div className="bg-accent/10 border border-accent/20 rounded-2xl p-5">
          <div className="text-sm text-accent-foreground/80 mb-1">Trafi do:</div>
          <div>Zarząd Zieleni m.st. Warszawy</div>
        </div>
      </div>

      {/* Send Button */}
      <div className="p-6 border-t border-border bg-card">
        <button
          onClick={handleSend}
          className="w-full bg-primary text-primary-foreground rounded-2xl py-4 px-6 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-sm"
        >
          <Send className="w-5 h-5" />
          <span>Wyślij zgłoszenie</span>
        </button>
      </div>
    </div>
  );
}
