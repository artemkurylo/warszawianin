import { Camera, Image as ImageIcon, X } from 'lucide-react';
import { useState } from 'react';

interface CameraScreenProps {
  onNavigate: (screen: string) => void;
  onPhotoCapture: (hasPhoto: boolean) => void;
}

export function CameraScreen({ onNavigate, onPhotoCapture }: CameraScreenProps) {
  const [photoTaken, setPhotoTaken] = useState(false);

  const handleCapture = () => {
    setPhotoTaken(true);
    setTimeout(() => {
      onPhotoCapture(true);
      onNavigate('preview');
    }, 600);
  };

  return (
    <div className="flex flex-col h-full bg-foreground relative">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 p-6 flex items-center justify-between">
        <button
          onClick={() => onNavigate('home')}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white"
        >
          <X className="w-6 h-6" />
        </button>
        <div className="text-white text-sm">Zrób zdjęcie problemu</div>
        <div className="w-10" />
      </div>

      {/* Camera Viewfinder */}
      <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900">
        {!photoTaken ? (
          <div className="text-center text-white/60">
            <Camera className="w-20 h-20 mx-auto mb-4" />
            <div>Wskaż na problem w mieście</div>
          </div>
        ) : (
          <div className="text-white text-center">
            <div className="animate-pulse">Przetwarzanie...</div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
        <div className="flex items-center justify-center gap-8">
          <button className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white">
            <ImageIcon className="w-6 h-6" />
          </button>
          <button
            onClick={handleCapture}
            disabled={photoTaken}
            className="w-20 h-20 rounded-full bg-white border-4 border-white/40 active:scale-95 transition-transform disabled:opacity-50"
          />
          <div className="w-14 h-14" />
        </div>
      </div>
    </div>
  );
}
